import logging
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler

BOT_TOKEN = "7599401176:AAGyAW50cRzK0j9oRBHOlztN8dM00nCWwwM"
ADMIN_ID = 7279685381
USD_RATE = 13200
SMM_API_KEY = "8b9a4e602c87dcd95ea67c6fed3fb5e5"

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Start komandasi
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        ["Barcha xizmatlar", "Buyurtmalar"],
        ["Referal", "Mening hisobim"],
        ["Hisobni to'ldirish", "Murojaat"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Assalomu alaykum! SMM botga xush kelibsiz.", reply_markup=reply_markup)

async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text == "Barcha xizmatlar":
        msg = "Xizmatlar kategoriyasi:
• Telegram
• Instagram
• TikTok
• YouTube"
        await update.message.reply_text(msg)

    elif text == "Buyurtmalar":
        await update.message.reply_text("Sizning buyurtmalaringiz hozircha yo'q.")

    elif text == "Referal":
        user_id = update.message.from_user.id
        ref_link = f"https://t.me/smmuppercom_robot?start={user_id}"
        msg = f"Sizning referal havolangiz:
{ref_link}

Har bir taklif qilingan foydalanuvchi uchun 50 so'm beriladi."
        await update.message.reply_text(msg)

    elif text == "Mening hisobim":
        msg = (
            f"**👤 ID raqamingiz:** {update.message.from_user.id}
"
            f"**💰 Balansingiz:** 0 so'm
"
            f"📊 Buyurtmalaringiz: 0 ta
"
            f"🗣 Referallaringiz: 0 ta
"
            f"⬆️ Kiritgan pullaringiz: 0 so'm"
        )
        await update.message.reply_text(msg, parse_mode="Markdown")

    elif text == "Hisobni to'ldirish":
        keyboard = [
            [InlineKeyboardButton("Uzcard", callback_data="pay_uzcard")],
            [InlineKeyboardButton("Humo", callback_data="pay_humo")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("To'lov turini tanlang:", reply_markup=reply_markup)

    elif text == "Murojaat":
        await update.message.reply_text("Murojaat matnini yozib yuboring.")
        context.user_data["awaiting_support"] = True

    else:
        # Murojaat uchun
        if context.user_data.get("awaiting_support", False):
            await update.message.reply_text("Murojaatingiz qabul qilindi.")
            context.user_data["awaiting_support"] = False
        else:
            await update.message.reply_text("Iltimos, menyudan tanlang.")

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "pay_uzcard":
        msg = (
            "To'lov tizimi: Uzcard
"
            "💳 Hamyon: `5614682419952215`
"
            "Ism: Burxonov Bekmurod

"
            "Chekni @chat_bilan joylang iltimos.
"
            "✅ To'lovlar 5 daqiqadan 12 soatgacha tasdiqlanadi."
        )
        await query.edit_message_text(msg, parse_mode="Markdown")
    elif query.data == "pay_humo":
        msg = (
            "To'lov tizimi: Humo
"
            "💳 Hamyon: `9860180111646451`
"
            "Ism: Burxonov Bekmurod

"
            "Chekni @chat_bilan joylang iltimos.
"
            "✅ To'lovlar 5 daqiqadan 12 soatgacha tasdiqlanadi."
        )
        await query.edit_message_text(msg, parse_mode="Markdown")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, menu_handler))
    app.add_handler(CallbackQueryHandler(button_callback))
    app.run_polling()

if __name__ == '__main__':
    main()
