# SMMUpper Telegram Bot v2

Tugmalar va referal tizimi bilan.
